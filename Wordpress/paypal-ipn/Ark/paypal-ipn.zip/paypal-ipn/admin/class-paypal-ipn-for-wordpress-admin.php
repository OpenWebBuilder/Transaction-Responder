<?php

/**
 * @class       AngellEYE_Paypal_Ipn_For_Wordpress_Admin
 * @version	1.0.0
 * @package	paypal-ipn-for-wordpress
 * @category	Class
 * @author      Angell EYE <service@angelleye.com>
 */
class AngellEYE_Paypal_Ipn_For_Wordpress_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @var      string    $plugin_name       The name of this plugin.
     * @var      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->load_dependencies();
    }

    /**
     * Register the stylesheets for the Dashboard.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        /**
         *
         * An instance of this class should be passed to the run() function
         * defined in AngellEYE_Paypal_Ipn_For_Wordpress_Admin_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The AngellEYE_Paypal_Ipn_For_Wordpress_Admin_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/paypal-ipn-for-wordpress-admin.css', array(), $this->version, 'all');
    }

    public function admin_enqueue_scripts() {
        /**
         * add code prettify jquery
         */
        global $post_type;
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/paypal-ipn-for-wordpress-admin.js', array('jquery'), $this->version, true);
        if ($post_type == "paypal_ipn") {
            $script = 'run_prettify.js';
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                $script = 'run_prettify-src.js';
            }
            $script_url = plugins_url( sprintf( 'prettify/%s', $script ), __FILE__ );
            $skin = apply_filters( 'prettify_skin', null );
            if ( $skin ) {
                $script_url = add_query_arg( 'skin', $skin, $script_url );
            }
            $script_url = apply_filters( 'code-prettify-js-url', $script_url );
            wp_enqueue_script('code-prettify', $script_url, array('jquery'), $this->version, true);
            wp_localize_script('code-prettify', 'code_prettify_settings', array( 'base_url' => plugins_url( 'prettify', __FILE__ )));
            
        }
    }

    private function load_dependencies() {

        /**
         * The class responsible for defining all actions that occur in the Dashboard for IPN Listing
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/partials/class-paypal-ipn-for-wordpress-post-types.php';

        /**
         * The class responsible for defining all actions that occur in the Dashboard
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/partials/paypal-ipn-for-wordpress-admin-display.php';

        /**
         * The class responsible for defining function for display Html element
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/partials/class-paypal-ipn-for-wordpress-html-output.php';

        /**
         * The class responsible for defining function for display general setting tab
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/partials/class-paypal-ipn-for-wordpress-general-setting.php';
    }

    /**
     * modify wordpress search query
     *
     * @since    1.0.4
     */
    public function paypal_ipn_for_wordpress_modify_wp_search($where) {

        global $wpdb, $wp;

        if (isset($_GET['s']) && !empty($_GET['s'])) {
            if (is_search() && isset($_GET['post_type']) && $_GET['post_type'] == 'paypal_ipn') {
                $where = preg_replace(
                        "/($wpdb->posts.post_title (LIKE '%{$wp->query_vars['s']}%'))/i", "$0 OR ( $wpdb->postmeta.meta_value LIKE '%{$wp->query_vars['s']}%' )", $where
                );
                add_filter('posts_join_request', array(__CLASS__, 'paypal_ipn_for_wordpress_modify_wp_search_join'));
                add_filter('posts_distinct_request', array(__CLASS__, 'paypal_ipn_for_wordpress_modify_wp_search_distinct'));
            }
        }

        return $where;
    }

    /**
     * wordpress join search query
     *
     * @since    1.0.4
     */
    public static function paypal_ipn_for_wordpress_modify_wp_search_join($join) {

        global $wpdb;

        return $join .= " LEFT JOIN $wpdb->postmeta ON ($wpdb->posts.ID = $wpdb->postmeta.post_id) ";
    }

    /**
     * wordpress distinct search query
     *
     * @since    1.0.4
     */
    public static function paypal_ipn_for_wordpress_modify_wp_search_distinct($distinct) {

        return 'DISTINCT';
    }
    
    /**
     * @since    1.1 
     * @param type $actions
     * @param type $post
     * View link goes to 404 Not Found Issue #69
     */
    public function paypal_ipn_for_wordpress_remove_row_actions($actions, $post) {
        $current_screen = get_current_screen();
        if( $current_screen->post_type == 'paypal_ipn' ) {
            unset( $actions['view'] );
            unset( $actions['inline hide-if-no-js'] );
        }
        return $actions;
    }
    
    public function paypal_ipn_for_wordpress_remove_postmeta($pid) {
        global $wpdb;
        if( get_post_type($pid) == 'paypal_ipn' || get_post_type($pid) == 'ipn_history' ) {
            if ( $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE post_id = %d", $pid ) ) ) {
                $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d", $pid ) );
            }
        }
    }
    
    public function angelleye_paypal_ipn_for_wordpress_display_push_notification() {
        global $current_user;
        $user_id = $current_user->ID;
        if (false === ( $response = get_transient('angelleye_paypal_ipn_push_notification_result') )) {
            $response = $this->angelleye_get_push_notifications();
            if(is_object($response)) {
                set_transient('angelleye_paypal_ipn_push_notification_result', $response, 12 * HOUR_IN_SECONDS);
            }
        }
        if (is_object($response)) {
            foreach ($response->data as $key => $response_data) {
                if (!get_user_meta($user_id, $response_data->id)) {
                    $this->angelleye_display_push_notification($response_data);
                }
            }
        }
    }

    public function angelleye_get_push_notifications() {
        $args = array(
            'plugin_name' => 'paypal-ipn',
        );
        $api_url = PAYPAL_FOR_WOOCOMMERCE_PUSH_NOTIFICATION_WEB_URL . '?Wordpress_Plugin_Notification_Sender';
        $api_url .= '&action=angelleye_get_plugin_notification';
        $request = wp_remote_post($api_url, array(
            'method' => 'POST',
            'timeout' => 45,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array('user-agent' => 'AngellEYE'),
            'body' => $args,
            'cookies' => array(),
            'sslverify' => false
        ));
        if (is_wp_error($request) or wp_remote_retrieve_response_code($request) != 200) {
            return false;
        }
        if ($request != '') {
            $response = json_decode(wp_remote_retrieve_body($request));
        } else {
            $response = false;
        }
        return $response;
    }

    public function angelleye_display_push_notification($response_data) {
        echo '<div class="notice notice-success angelleye-notice" style="display:none;" id="'.$response_data->id.'">'
        . '<div class="angelleye-notice-logo-push"><span> <img src="' . $response_data->ans_company_logo . '"> </span></div>'
        . '<div class="angelleye-notice-message">'
        . '<h3>' . $response_data->ans_message_title . '</h3>'
        . '<div class="angelleye-notice-message-inner">'
        . '<p>' . $response_data->ans_message_description . '</p>'
        . '<div class="angelleye-notice-action"><a target="_blank" href="' . $response_data->ans_button_url . '" class="button button-primary">' . $response_data->ans_button_label . '</a></div>'
        . '</div>'
        . '</div>'
        . '<div class="angelleye-notice-cta">'
        . '<button class="angelleye-notice-dismiss angelleye-dismiss-welcome" data-msg="' . $response_data->id . '">Dismiss</button>'
        . '</div>'
        . '</div>';
    }
    
    public function angelleye_paypal_ipn_for_wordpress_adismiss_notice() {
        global $current_user;
        $user_id = $current_user->ID;
        if (!empty($_POST['action']) && $_POST['action'] == 'angelleye_paypal_ipn_for_wordpress_adismiss_notice') {
            add_user_meta($user_id, stripslashes_deep($_POST['data']), 'true', true);
            wp_send_json_success();
        }
    }
}
