###################
Introduction
###################

A PayPal Instant Payment Notification (IPN) toolkit that helps you automate tasks in real-time when transactions hit your PayPal account.

 * All PayPal IPN data is saved and available in your WordPress admin panel.
 * Developer hooks are provided for triggering events based on the transaction type or payment status of the IPN.
 * Extend the plugin with your own plugins or theme functions, or check out our premium extensions for easy automation of various tasks.

************
Installation
************

Automatic Installation
----------------------
Automatic installation is the easiest option as WordPress handles the file transfers itself and you don't need to leave your web browser. To do an automatic install, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type "PayPal IPN for WordPress" and click Search Plugins. Once you've found our plugin you can view details about it such as the the rating and description. Most importantly, of course, you can install it by simply clicking Install Now.

Manual Installation
-------------------
 1. Unzip the files and upload the folder into your plugins folder (wp-content/plugins/) overwriting old versions if they exist
 2. Activate the plugin in your WordPress admin area.
 3. Settings are available in the WordPress admin area under Settings -> PayPal IPN.

*********
Setup
*********

Take a look at `PayPal's IPN Setup Guide <https://developer.paypal.com/docs/classic/ipn/integration-guide/IPNSetup/>`_ for details on enabling IPN within your PayPal account.

You can find your IPN URL under Settings -> PayPal IPN in your WordPress admin panel.

*********
Resources
*********

-  `Introduction to IPN <https://developer.paypal.com/webapps/developer/docs/classic/ipn/integration-guide/IPNIntro/>`_
-  `Configure IPN in a PayPal Account <https://developer.paypal.com/webapps/developer/docs/classic/ipn/integration-guide/IPNSetup/>`_
-  `Testing IPN <https://developer.paypal.com/webapps/developer/docs/classic/ipn/integration-guide/IPNTesting/>`_
-  `IPN Variables List <https://developer.paypal.com/docs/api-basics/notifications/ipn/IPNandPDTVariables/>`_
